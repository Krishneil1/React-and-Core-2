﻿using System;

namespace SpyStore.DAL.Tests
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
