﻿using System;

namespace SpyStore.Models
{
    public class Class1
    {
    }
}
