﻿using System;

namespace SpyStore.DAL
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
